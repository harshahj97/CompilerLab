lex threeaddr.l
yacc threeaddr.y -d
g++ lex.yy.c threeaddr.tab.c -lfl
./a.out < input.txt
