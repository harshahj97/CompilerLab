lex ArithEval.l
yacc -d ArithEval.y
gcc -o ArithEval lex.yy.c y.tab.c
./ArithEval
