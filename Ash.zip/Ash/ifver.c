int main()
{
	if(a<b)
	{
		if(a>c)
		{
			a=b;
		}
		else
		{
			a=d;
		
	}
	else
	{
		b=d;
	}
}
