lex VarCon.l
gcc -o VarCon lex.yy.c
./VarCon < VarConTest.txt
