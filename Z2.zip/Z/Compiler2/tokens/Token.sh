lex C_Tokens.l
gcc -o Tokenizer lex.yy.c
./Tokenizer < Token_Test.c
