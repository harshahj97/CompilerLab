lex InPos.l
yacc InPos.y
gcc -o InPos y.tab.c -ll -ly
./InPos
