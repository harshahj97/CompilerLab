lex for.l
yacc for.y
gcc -o for y.tab.c -ll -ly
./for < input.txt
