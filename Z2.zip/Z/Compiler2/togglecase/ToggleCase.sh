lex ToggleCase.l
gcc -o ToggleCase lex.yy.c
./ToggleCase < ToggleCaseTest.txt
