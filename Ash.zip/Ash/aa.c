int main()
{
	for(i=0;i<n;i++)
	{
		cout << i
	}
}
