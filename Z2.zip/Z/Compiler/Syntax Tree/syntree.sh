lex syntree.l
yacc -d syntree.y
gcc -o SynTree y.tab.c -lfl
./SynTree < input.txt
