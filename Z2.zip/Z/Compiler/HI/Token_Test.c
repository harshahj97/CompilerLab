#include<stdio.h>
float f=20.2;
int main()
{
	int number=11;
	h=hi--;
	printf("%d",hi);
	if(i==10)
	{
		return 10;
	}
	return 0;
}
