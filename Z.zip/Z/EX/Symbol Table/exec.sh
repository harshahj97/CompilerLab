lex table.l
yacc table.y -d
g++ lex.yy.c y.tab.c -ll -ly
./a.out
