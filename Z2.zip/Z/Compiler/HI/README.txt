Arithmetic Evaluation:
	lex ArithEval.l
	yacc -d ArithEval.y
	gcc -o ArithEval lex.yy.c y.tab.c
	./ArithEval
	
Toggle Case:
	lex ToggleCase.l
	gcc -o ToggleCase lex.yy.c
	./ToggleCase < ToggleCaseTest.txt
	
Variable Constant:
	lex VarCon.l
	gcc -o VarCon lex.yy.c
	./VarCon < VarConTest.txt
	
For loop:
	lex for.l
	yacc for.y
	gcc -o for y.tab.c -ll -ly
	./for
	
Tokenizer:
	lex C_Tokens.l
	gcc -o Tokenizer lex.yy.c
	./Tokenizer < Token_Test.c
	
Infix to postfix conversion:
	lex InPos.l
	yacc InPos.y
	gcc -o InPos y.tab.c -ll -ly
	./InPos
	
Infix to prefix conversion:
	
